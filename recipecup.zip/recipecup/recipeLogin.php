<?php

$data=file_get_contents('php://input');
$decoded_data=json_decode($data,true);
$output=$decoded_data['name'];
$output2=$decoded_data['pas'];

$connection = mysqli_connect('localhost','root','');

mysqli_select_db($connection , 'recipecup');

$result = mysqli_query($connection , "select * from users where Email='$output'");

$no_of_rows=mysqli_num_rows($result);	
if($no_of_rows>0)
{
	$row=mysqli_fetch_array($result);
	$saved_password=$row['Password'];
	if($saved_password==$output2)
	{ $key['pass_key']="Password Matched";

      $key['user_id'] = $row['user_id'];
echo json_encode($key);
	}
	else
	{
		$key['pass_key']="Enter Correct password";
		echo json_encode($key);
	}
	
}
else
{
	$key['pass_key']="no user";
	echo json_encode($key);
}
	?>