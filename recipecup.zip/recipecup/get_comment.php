<?php



$json = file_get_contents('php://input');

//convert json object to php associative array
$data = json_decode($json, true);

$r_id = $data['r_id'];




$db = mysqli_connect("localhost","root", ""); 

if (!$db)
 { die('Could not connect to db: ' . mysqli_error());
   echo "error";
    }
  //Select the Database
   mysqli_select_db($db, 'recipecup');

   $output = array();
   
   
   $query = mysqli_query($db,"Select a.* , b.Name from comments a , users b where a.R_Id = '$r_id' and a.posted_by = b.user_id");
   
   while($r = mysqli_fetch_assoc($query))
	   array_push($output , $r);
   
   $response['result'] = $output ;
   
   echo json_encode($response);
    
    ?>
   
    