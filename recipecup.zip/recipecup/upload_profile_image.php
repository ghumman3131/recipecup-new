<?php


   $json = file_get_contents('php://input');
    //convert json object to php associative array
   $data = json_decode($json, true);
  $image = $data['image'];
  $user_id = $data['user_id'];
   $db = mysqli_connect("localhost","root", ''); 
  
   mysqli_select_db($db, 'recipecup'); // your database name here
   
   $query = mysqli_query($db,"update users set Image_upload = '$image' where user_id = '$user_id' ");
   
   if($query){
 
   $response['result'] = "done";
  echo json_encode($response);
    }
	
	else {
		
		 $response['result'] = "not done";
  echo json_encode($response);
		
	}
    
    ?>
   