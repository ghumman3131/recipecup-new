<?php
$data = file_get_contents('php://input');

$data_decoded = json_decode($data , true);

$recipename = $data_decoded['key_id'];

$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'recipecup');

$result = mysqli_query($connection , "select * from recipes where R_Name = '$recipename'");

$rows_found = mysqli_num_rows($result);
if ($rows_found>0)
{
	$row = mysqli_fetch_array($result);
	$response['result'] = "found";
	$response['rrname'] = $row['R_Name'];
	$response['ttype'] = $row['Type'];
	$response['iingredients'] = $row['Ingredients'];
	$response['ssteps'] = $row['Steps'];
	$response['rratings'] = $row['Ratings'];
	echo json_encode($response);
	
}
else
{
 $response['result']= "not found" ;
 echo json_encode($response);

}

?>
