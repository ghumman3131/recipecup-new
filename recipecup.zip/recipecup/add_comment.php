<?php

 

$json = file_get_contents('php://input');

//convert json object to php associative array
$data = json_decode($json, true);

$recipe_id = $data['r_id'];
$comment = $data['comment'];
$user_id = $data['user_id'];

date_default_timezone_set('Asia/Kolkata');

$date = date('Y/m/d' , time());



$db = mysqli_connect("localhost","root", ""); 

if (!$db)
 { die('Could not connect to db: ' . mysqli_error());
   echo "error";
    }
  //Select the Database
   mysqli_select_db($db, 'recipecup');

   
   $query = mysqli_query($db,"insert into comments (R_Id , comment , posted_by , date ) values ('$recipe_id' , '$comment' , '$user_id' , '$date' ) ");
   
   if($query){
 
   $response['key'] = "done";
  echo json_encode($response);

    }
	
	else {
		
		 $response['key'] = "not done";
  echo json_encode($response);
		
	}
    
    ?>
   
    