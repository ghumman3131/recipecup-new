
<?php



$data = file_get_contents('php://input');

$data_decoded = json_decode($data , true);

$user_id = $data_decoded['user_id'];

$connection = mysqli_connect('localhost' , 'root' , '');
// selecting database
mysqli_select_db($connection , 'recipecup');

$result = mysqli_query($connection, "select * from users where user_id = '$user_id'  ");

while($r = mysqli_fetch_assoc($result))
	

   $response['result'] = $r;
   
   echo json_encode($response);



?>

