<?php

$data = file_get_contents('php://input');

$data_decoded = json_decode($data , true);

$tipscell = $data_decoded ['key_id'];

$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'recipecup');

$status = mysqli_query($connection , "select tips_id , tips from recipes where R_Name LIKE '%$tipscell%'");

while($koi = mysqli_fetch_assoc($status))

    $response[] = $koi;
	
	$result['result'] = $response;
	
	
echo json_encode($result);
	
?>