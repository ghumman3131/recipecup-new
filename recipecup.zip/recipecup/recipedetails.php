<?php

$data = file_get_contents('php://input');

$data_decoded = json_decode($data , true);

$rid = $data_decoded ['recipe_id'];

$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'recipecup');

$status = mysqli_query($connection , "select * from recipes where R_Id = '$rid'");

$koi = mysqli_fetch_assoc($status);

    $response = $koi;
	
echo json_encode($response);
	
?>