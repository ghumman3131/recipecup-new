<?php
$data = file_get_contents('php://input');

$data_decoded = json_decode($data , true);

$recipename = $data_decoded['name_k'];

$steps = $data_decoded[ 'stepss_k'];

$ingredient = $data_decoded['ingredient'];
$recipe_by = $data_decoded['recipe_by'];
$type = $data_decoded ['type'];

$connection = mysqli_connect('localhost' , 'root' , '');


mysqli_select_db($connection , 'recipecup');

$result = mysqli_query($connection , "select R_Name from recipes where R_Name = '$recipename'");

$rows_found = mysqli_num_rows($result);

if($rows_found == 0){

mysqli_query($connection, "insert into recipes (R_Name ,Ingredients , Type, Steps , RecipeBy) 
values ('$recipename' ,'$ingredient' , '$type' , '$steps' , '$recipe_by' ) " );
        $response['key'] = "1";

	echo json_encode($response);
}
else {
	$response['key'] = "0";

	echo json_encode($response);
}
?>