<?php

$data = file_get_contents('php://input');

$data_decoded = json_decode($data , true);

$tips = $data_decoded ['tip_key'];

$connection = mysqli_connect('localhost' , 'root' , '');

mysqli_select_db($connection , 'recipecup');

$status = mysqli_query($connection , "select a.* , b.* from category a , tips b where a.category_name = '$tips' and b.category_id = a.category_id ");

while($koi = mysqli_fetch_assoc($status))

    $response[] = $koi;
	
	$result['result'] = $response;
	
	
echo json_encode($result);
	
?>